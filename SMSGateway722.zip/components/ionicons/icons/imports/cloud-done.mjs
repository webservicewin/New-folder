import ios from '../../dist/ionicons/svg/ios-cloud-done.svg';
import md from '../../dist/ionicons/svg/md-cloud-done.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};