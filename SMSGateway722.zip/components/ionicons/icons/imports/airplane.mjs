import ios from '../../dist/ionicons/svg/ios-airplane.svg';
import md from '../../dist/ionicons/svg/md-airplane.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};