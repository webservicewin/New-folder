import ios from '../../dist/ionicons/svg/ios-backspace.svg';
import md from '../../dist/ionicons/svg/md-backspace.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};