module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-checkmark-circle.svg'),
  md: require('../../dist/ionicons/svg/md-checkmark-circle.svg')
};