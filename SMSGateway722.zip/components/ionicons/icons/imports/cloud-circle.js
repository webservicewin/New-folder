module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-cloud-circle.svg'),
  md: require('../../dist/ionicons/svg/md-cloud-circle.svg')
};