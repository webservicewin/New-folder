import ios from '../../dist/ionicons/svg/ios-beer.svg';
import md from '../../dist/ionicons/svg/md-beer.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};