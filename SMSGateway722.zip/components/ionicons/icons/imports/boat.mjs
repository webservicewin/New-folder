import ios from '../../dist/ionicons/svg/ios-boat.svg';
import md from '../../dist/ionicons/svg/md-boat.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};