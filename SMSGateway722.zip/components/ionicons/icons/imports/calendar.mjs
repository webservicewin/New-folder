import ios from '../../dist/ionicons/svg/ios-calendar.svg';
import md from '../../dist/ionicons/svg/md-calendar.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};