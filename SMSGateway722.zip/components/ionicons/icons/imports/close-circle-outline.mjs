import ios from '../../dist/ionicons/svg/ios-close-circle-outline.svg';
import md from '../../dist/ionicons/svg/md-close-circle-outline.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};