module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-cellular.svg'),
  md: require('../../dist/ionicons/svg/md-cellular.svg')
};