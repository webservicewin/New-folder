module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-barcode.svg'),
  md: require('../../dist/ionicons/svg/md-barcode.svg')
};