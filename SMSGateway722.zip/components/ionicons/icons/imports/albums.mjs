import ios from '../../dist/ionicons/svg/ios-albums.svg';
import md from '../../dist/ionicons/svg/md-albums.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};