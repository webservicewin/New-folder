module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-arrow-back.svg'),
  md: require('../../dist/ionicons/svg/md-arrow-back.svg')
};