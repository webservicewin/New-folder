module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-bug.svg'),
  md: require('../../dist/ionicons/svg/md-bug.svg')
};