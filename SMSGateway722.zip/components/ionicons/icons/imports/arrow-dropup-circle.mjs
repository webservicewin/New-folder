import ios from '../../dist/ionicons/svg/ios-arrow-dropup-circle.svg';
import md from '../../dist/ionicons/svg/md-arrow-dropup-circle.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};