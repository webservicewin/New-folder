import ios from '../../dist/ionicons/svg/ios-battery-full.svg';
import md from '../../dist/ionicons/svg/md-battery-full.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};