import ios from '../../dist/ionicons/svg/ios-cloudy-night.svg';
import md from '../../dist/ionicons/svg/md-cloudy-night.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};