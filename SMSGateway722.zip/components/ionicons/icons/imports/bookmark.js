module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-bookmark.svg'),
  md: require('../../dist/ionicons/svg/md-bookmark.svg')
};