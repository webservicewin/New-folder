module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-body.svg'),
  md: require('../../dist/ionicons/svg/md-body.svg')
};