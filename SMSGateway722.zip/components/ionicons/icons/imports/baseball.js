module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-baseball.svg'),
  md: require('../../dist/ionicons/svg/md-baseball.svg')
};