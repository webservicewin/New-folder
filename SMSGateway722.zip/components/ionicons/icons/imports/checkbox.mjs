import ios from '../../dist/ionicons/svg/ios-checkbox.svg';
import md from '../../dist/ionicons/svg/md-checkbox.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};