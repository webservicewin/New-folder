import ios from '../../dist/ionicons/svg/ios-body.svg';
import md from '../../dist/ionicons/svg/md-body.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};