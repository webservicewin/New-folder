<?php
/**
 * @var User $logged_in_user
 */

try {
    require_once __DIR__ . "/../includes/login.php";

    if (empty($_POST["mobileNumber"]) || empty($_POST["devices"]) || empty($_POST["message"])) {
        throw new Exception(__("error_missing_fields"));
    } else {
        $messages = [];
        $attachments = $logged_in_user->upload("attachments");
        $attachments = count($attachments) > 0 ? implode(',', $attachments) : null;
        $mobileNumbers = explode(",", $_POST["mobileNumber"]);
        foreach ($mobileNumbers as $mobileNumber) {
            $messages[] = ['number' => $mobileNumber, 'message' => $_POST["message"], 'attachments' => $attachments, 'type' => $_POST["type"]];
        }
        $schedule = null;
        if (isset($_POST["schedule"])) {
            $schedule = new DateTime($_POST["schedule"], new DateTimeZone($_SESSION["timeZone"]));
            $schedule = $schedule->getTimestamp();
        }
        Message::sendMessages($messages, $logged_in_user, is_array($_POST["devices"]) ? $_POST["devices"] : [$_POST["devices"]], $schedule, $_POST["prioritize"]);
        $success = is_null($schedule) ? __("success_sent") : __("success_scheduled");
        echo json_encode([
            "result" => $success
        ]);
    }
} catch (Throwable $t) {
    echo json_encode(array(
        'error' => $t->getMessage()
    ));
}