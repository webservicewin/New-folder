<?php
/**
 * @var User $logged_in_user
 * @var Device $currentDevice
 */

try {
    require_once __DIR__ . "/../includes/ajax_protect.php";
    require_once __DIR__ . "/../includes/login.php";

    MysqliDb::getInstance()->startTransaction();
    if (isset($_COOKIE["DEVICE_ID"])) {
        $name = $_POST["name"];
        if (function_exists('mb_strlen')) {
            $length = mb_strlen($name, 'UTF-8');
        } else {
            $length = strlen($name);
        }
        if ($length > 25) {
            throw new Exception(__("error_device_name"));
        } else {
            $currentDevice->setName($name);
            $currentDevice->save();
        }
    }
    User::getDevice($_POST["device"], $_SESSION["userID"]);
    $logged_in_user->setPrimaryDeviceID($_POST["device"]);
    $logged_in_user->save();
    MysqliDb::getInstance()->commit();
    echo json_encode([
        'result' => __("success_device_settings")
    ]);
} catch (Throwable $t) {
    echo json_encode(array(
        'error' => $t->getMessage()
    ));
}
