
import DataTable from 'datatables.net-responsive';

export default DataTable;
export * from 'datatables.net-responsive';
