module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-arrow-dropright-circle.svg'),
  md: require('../../dist/ionicons/svg/md-arrow-dropright-circle.svg')
};