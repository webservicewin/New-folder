module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-basket.svg'),
  md: require('../../dist/ionicons/svg/md-basket.svg')
};