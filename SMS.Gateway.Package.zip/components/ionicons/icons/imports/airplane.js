module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-airplane.svg'),
  md: require('../../dist/ionicons/svg/md-airplane.svg')
};