import ios from '../../dist/ionicons/svg/ios-bookmark.svg';
import md from '../../dist/ionicons/svg/md-bookmark.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};