module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-arrow-round-up.svg'),
  md: require('../../dist/ionicons/svg/md-arrow-round-up.svg')
};