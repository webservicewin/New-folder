import ios from '../../dist/ionicons/svg/ios-call.svg';
import md from '../../dist/ionicons/svg/md-call.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};