import ios from '../../dist/ionicons/svg/ios-baseball.svg';
import md from '../../dist/ionicons/svg/md-baseball.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};