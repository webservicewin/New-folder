module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-calendar.svg'),
  md: require('../../dist/ionicons/svg/md-calendar.svg')
};