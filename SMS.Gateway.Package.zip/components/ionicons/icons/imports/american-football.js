module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-american-football.svg'),
  md: require('../../dist/ionicons/svg/md-american-football.svg')
};