import ios from '../../dist/ionicons/svg/ios-checkbox-outline.svg';
import md from '../../dist/ionicons/svg/md-checkbox-outline.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};