module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-alarm.svg'),
  md: require('../../dist/ionicons/svg/md-alarm.svg')
};