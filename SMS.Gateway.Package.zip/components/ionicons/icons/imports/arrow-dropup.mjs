import ios from '../../dist/ionicons/svg/ios-arrow-dropup.svg';
import md from '../../dist/ionicons/svg/md-arrow-dropup.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};