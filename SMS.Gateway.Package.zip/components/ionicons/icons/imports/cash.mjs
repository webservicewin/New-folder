import ios from '../../dist/ionicons/svg/ios-cash.svg';
import md from '../../dist/ionicons/svg/md-cash.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};