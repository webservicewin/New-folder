import ios from '../../dist/ionicons/svg/ios-analytics.svg';
import md from '../../dist/ionicons/svg/md-analytics.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};