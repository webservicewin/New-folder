import ios from '../../dist/ionicons/svg/ios-cafe.svg';
import md from '../../dist/ionicons/svg/md-cafe.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};