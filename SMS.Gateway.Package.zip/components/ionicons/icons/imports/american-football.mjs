import ios from '../../dist/ionicons/svg/ios-american-football.svg';
import md from '../../dist/ionicons/svg/md-american-football.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};