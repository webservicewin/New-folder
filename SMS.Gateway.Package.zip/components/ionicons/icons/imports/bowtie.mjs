import ios from '../../dist/ionicons/svg/ios-bowtie.svg';
import md from '../../dist/ionicons/svg/md-bowtie.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};