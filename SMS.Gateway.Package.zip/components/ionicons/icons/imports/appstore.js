module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-appstore.svg'),
  md: require('../../dist/ionicons/svg/md-appstore.svg')
};