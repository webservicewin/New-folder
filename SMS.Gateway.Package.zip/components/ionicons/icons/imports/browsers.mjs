import ios from '../../dist/ionicons/svg/ios-browsers.svg';
import md from '../../dist/ionicons/svg/md-browsers.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};