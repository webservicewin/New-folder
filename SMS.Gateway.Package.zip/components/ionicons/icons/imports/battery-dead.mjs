import ios from '../../dist/ionicons/svg/ios-battery-dead.svg';
import md from '../../dist/ionicons/svg/md-battery-dead.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};