import ios from '../../dist/ionicons/svg/ios-chatboxes.svg';
import md from '../../dist/ionicons/svg/md-chatboxes.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};