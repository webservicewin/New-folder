import ios from '../../dist/ionicons/svg/ios-arrow-up.svg';
import md from '../../dist/ionicons/svg/md-arrow-up.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};